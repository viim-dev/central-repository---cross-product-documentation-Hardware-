# Contributing to Aware OS

Thank you for your interest in contributing to Aware OS! We welcome contributions from the community to help make Aware OS the best operating system for spatial computing.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Development Setup](#development-setup)
- [Coding Guidelines](#coding-guidelines)
- [Submitting Changes](#submitting-changes)
- [Reporting Bugs](#reporting-bugs)
- [Suggesting Enhancements](#suggesting-enhancements)

## Code of Conduct

This project adheres to the Contributor Covenant Code of Conduct. By participating, you are expected to uphold this code. Please report unacceptable behavior to [conduct@viimtech.com](mailto:conduct@viimtech.com).

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check the existing issues to avoid duplicates. When creating a bug report, include as many details as possible:

- **Use a clear and descriptive title**
- **Describe the exact steps to reproduce the problem**
- **Provide specific examples** (code snippets, screenshots, videos)
- **Describe the behavior you observed** and what you expected
- **Include device information** (Visionaire glasses, vPhone model, Aware OS version)
- **Include logs** if applicable

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion:

- **Use a clear and descriptive title**
- **Provide a detailed description** of the suggested enhancement
- **Explain why this enhancement would be useful** to most Aware OS users
- **List any similar features** in other operating systems or apps

### Pull Requests

- Fill in the required template
- Follow the coding guidelines
- Include appropriate test coverage
- Update documentation as needed
- Ensure all tests pass

## Development Setup

1. **Install Aware OS Studio** (see README.md)
2. **Fork and clone the repository**:
   ```bash
   git clone https://github.com/YOUR-USERNAME/aware-os.git
   cd aware-os
   ```
3. **Create a branch** for your changes:
   ```bash
   git checkout -b feature/your-feature-name
   ```
4. **Build the project**:
   ```bash
   ./gradlew build
   ```
5. **Run tests**:
   ```bash
   ./gradlew test
   ```

## Coding Guidelines

### Code Style

- Follow the [Google Java Style Guide](https://google.github.io/styleguide/javaguide.html)
- Use meaningful variable and function names
- Write self-documenting code with clear comments for complex logic
- Keep functions small and focused on a single responsibility

### Commit Messages

- Use the present tense ("Add feature" not "Added feature")
- Use the imperative mood ("Move cursor to..." not "Moves cursor to...")
- Limit the first line to 72 characters or less
- Reference issues and pull requests liberally after the first line

Example:
```
Add gesture recognition for pinch-to-zoom

- Implement hand tracking for pinch gesture
- Add zoom functionality to AR content
- Update documentation with new gesture

Fixes #123
```

### Testing

- Write unit tests for new features
- Ensure all existing tests pass
- Aim for at least 80% code coverage
- Include integration tests for AR features

## Submitting Changes

1. **Push your changes** to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```
2. **Create a Pull Request** from your fork to the main repository
3. **Fill out the PR template** completely
4. **Wait for review** - maintainers will review your PR and may request changes
5. **Make requested changes** and push updates to your branch
6. **Merge** - once approved, your PR will be merged

## Reporting Bugs

Use the GitHub issue tracker to report bugs. Include:

- **Aware OS version**
- **Device model** (Visionaire glasses, vPhone)
- **Steps to reproduce**
- **Expected behavior**
- **Actual behavior**
- **Screenshots or videos** if applicable
- **Logs** (use `adb logcat` for device logs)

## Suggesting Enhancements

Use the GitHub issue tracker for enhancement suggestions. Include:

- **Clear use case** - why is this enhancement needed?
- **Proposed solution** - how would you implement this?
- **Alternatives considered** - what other approaches did you think about?
- **Additional context** - mockups, examples from other systems, etc.

---

Thank you for contributing to Aware OS! Your efforts help make spatial computing accessible to everyone.

**ViiM Technologies & AstroTek**

